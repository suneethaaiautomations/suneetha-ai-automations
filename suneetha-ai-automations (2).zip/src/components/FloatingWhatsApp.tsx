import { BUSINESS_CONFIG, buildWhatsAppUrl } from '../config/business';
import { WhatsAppIcon } from './WhatsAppIcon';

export function FloatingWhatsApp() {
  const href = buildWhatsAppUrl(BUSINESS_CONFIG.whatsappPrefilledMessage);

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with Suneetha AI Automations on WhatsApp"
      title="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-40 inline-flex h-13 w-13 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg shadow-black/35 ring-1 ring-white/20 hover:bg-[#1EBE5D] hover:scale-105 active:scale-95 transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#25D366]"
    >
      <WhatsAppIcon className="w-7 h-7" />
    </a>
  );
}
