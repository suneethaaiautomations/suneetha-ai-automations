import { useEffect, useState } from 'react';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';
import { Navbar } from './components/Navbar';
import { AboutPage } from './pages/AboutPage';
import { BookAppointmentPage } from './pages/BookAppointmentPage';
import { ContactPage } from './pages/ContactPage';
import { HomePage } from './pages/HomePage';
import { PortfolioPage } from './pages/PortfolioPage';
import { PricingPage } from './pages/PricingPage';
import { PrivacyPolicyPage } from './pages/PrivacyPolicyPage';
import { ServicesPage } from './pages/ServicesPage';
import { PageId, ServiceOptionLabel } from './types';

const VALID_PAGES: PageId[] = [
  'home',
  'services',
  'pricing',
  'portfolio',
  'about',
  'book',
  'contact',
  'privacy-policy',
];

function getInitialPage(): PageId {
  const normalizedPath = window.location.pathname.replace(/\/+$/, '') || '/';
  if (normalizedPath === '/privacy-policy') {
    return 'privacy-policy';
  }

  const hash = window.location.hash.replace('#', '').replace(/^\/+/, '') as PageId;
  return VALID_PAGES.includes(hash) ? hash : 'home';
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>(getInitialPage);
  const [preselectedService, setPreselectedService] = useState<ServiceOptionLabel | undefined>(
    undefined
  );

  useEffect(() => {
    const syncFromLocation = () => {
      setCurrentPage(getInitialPage());
    };
    window.addEventListener('hashchange', syncFromLocation);
    window.addEventListener('popstate', syncFromLocation);
    return () => {
      window.removeEventListener('hashchange', syncFromLocation);
      window.removeEventListener('popstate', syncFromLocation);
    };
  }, []);

  useEffect(() => {
    document.title =
      currentPage === 'privacy-policy'
        ? 'Privacy Policy — Suneetha AI Automations'
        : 'Suneetha AI Automations — Automate Smarter. Grow Faster.';
  }, [currentPage]);

  const handleNavigate = (page: PageId, service?: ServiceOptionLabel) => {
    if (service) {
      setPreselectedService(service);
    } else if (page !== 'book') {
      setPreselectedService(undefined);
    }

    setCurrentPage(page);

    if (page === 'privacy-policy') {
      if (window.location.pathname !== '/privacy-policy') {
        window.history.pushState(null, '', '/privacy-policy');
      }
    } else {
      const targetUrl = page === 'home' ? '/' : `/#${page}`;
      if (window.location.pathname !== '/' || window.location.hash !== (page === 'home' ? '' : `#${page}`)) {
        window.history.pushState(null, '', targetUrl);
      }
    }

    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    window.scrollTo({ top: 0, behavior: prefersReduced ? 'auto' : 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#080B18] text-[#F8FAFC]">
      <Navbar currentPage={currentPage} onNavigate={(page) => handleNavigate(page)} />

      <main className="flex-1">
        {currentPage === 'home' && <HomePage onNavigate={handleNavigate} />}
        {currentPage === 'services' && <ServicesPage onNavigate={handleNavigate} />}
        {currentPage === 'pricing' && <PricingPage onNavigate={handleNavigate} />}
        {currentPage === 'portfolio' && <PortfolioPage onNavigate={handleNavigate} />}
        {currentPage === 'about' && <AboutPage onNavigate={handleNavigate} />}
        {currentPage === 'book' && (
          <BookAppointmentPage preselectedService={preselectedService} />
        )}
        {currentPage === 'contact' && <ContactPage onNavigate={handleNavigate} />}
        {currentPage === 'privacy-policy' && <PrivacyPolicyPage onNavigate={handleNavigate} />}
      </main>

      <Footer onNavigate={(page) => handleNavigate(page)} />
      <FloatingWhatsApp />
    </div>
  );
}
