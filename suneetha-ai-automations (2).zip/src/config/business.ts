export const BUSINESS_CONFIG = {
  businessName: 'Suneetha AI Automations',
  displayName: 'SUNEETHA AI',
  secondaryBrandText: 'AUTOMATIONS',
  tagline: 'Automate Smarter. Grow Faster.',
  location: 'India',
  currency: 'INR',
  email: 'suneethapammi64@gmail.com',
  // Replace with your active WhatsApp Business number in international format without + or spaces (e.g., 919876543210)
  whatsappNumber: '919876543210',
  whatsappPrefilledMessage:
    'Hello Suneetha AI Automations, I am interested in your AI automation services. Please share more details.',
} as const;

export function buildMailtoUrl(subject: string, body: string): string {
  const encodedSubject = encodeURIComponent(subject);
  const encodedBody = encodeURIComponent(body);
  return `mailto:${BUSINESS_CONFIG.email}?subject=${encodedSubject}&body=${encodedBody}`;
}

export function buildWhatsAppUrl(
  message: string = BUSINESS_CONFIG.whatsappPrefilledMessage
): string {
  const cleanNumber = BUSINESS_CONFIG.whatsappNumber.replace(/\D/g, '');
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${cleanNumber}?text=${encodedMessage}`;
}
