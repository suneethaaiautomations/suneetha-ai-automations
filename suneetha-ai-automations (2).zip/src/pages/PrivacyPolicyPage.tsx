import { ArrowLeft, Mail } from 'lucide-react';
import { BUSINESS_CONFIG, buildMailtoUrl } from '../config/business';
import { PageId } from '../types';

interface PrivacyPolicyPageProps {
  onNavigate: (page: PageId) => void;
}

interface PolicySection {
  number: string;
  id: string;
  title: string;
  paragraphs: string[];
  bullets?: string[];
}

const EFFECTIVE_DATE = 'November 20, 2026';

const POLICY_SECTIONS: PolicySection[] = [
  {
    number: '01',
    id: 'introduction',
    title: 'Introduction',
    paragraphs: [
      `This Privacy Policy explains how ${BUSINESS_CONFIG.businessName} ("we", "our", or "us"), operating in ${BUSINESS_CONFIG.location}, collects, processes, and handles information when visitors browse our website, submit consultation or contact enquiries, or interact with our WhatsApp and AI automation messaging workflows.`,
      'By using this website or initiating communication with us through email or WhatsApp, you acknowledge the practices described in this Privacy Policy.',
    ],
  },
  {
    number: '02',
    id: 'information-we-collect',
    title: 'Information We Collect',
    paragraphs: [
      'Depending on how you interact with our website and messaging channels, we may receive the following information that you voluntarily provide:',
    ],
    bullets: [
      'Contact Form Enquiries: Your name, email address or phone number, selected enquiry topic, and message details.',
      'Appointment Consultation Requests: Your full name, optional business name, phone number, optional email address, business type, service of interest, preferred consultation date and time slot, and optional business requirements.',
      'WhatsApp Interactions: Your phone number, WhatsApp profile name (as shared by WhatsApp), and the contents of messages you send to us or to an automated WhatsApp assistant.',
      'Portfolio Media Previews: Files you choose to preview inside the Portfolio gallery uploader are processed locally in your browser session for display only and are not transmitted to an external server by this website.',
    ],
  },
  {
    number: '03',
    id: 'how-we-use-information',
    title: 'How We Use Information',
    paragraphs: [
      'This website uses client-side email and messaging handoffs rather than storing form submissions in an on-site website database:',
    ],
    bullets: [
      `Contact and Appointment Forms: Submitting our Contact or Book Appointment form prepares a formatted email draft in your email application addressed to ${BUSINESS_CONFIG.email}. Your details are sent to us only when you press Send in your email client.`,
      'WhatsApp Enquiries: Clicking "Chat on WhatsApp" or the floating WhatsApp button opens WhatsApp with a pre-filled enquiry message. Your message is shared only when you send it in WhatsApp.',
      'Purpose of Processing: We use the information you send to respond to your enquiries, coordinate and confirm requested consultation dates and times, discuss project scope and illustrative pricing, and deliver requested automation services.',
    ],
  },
  {
    number: '04',
    id: 'whatsapp-ai-automation',
    title: 'WhatsApp AI Automation and Messaging',
    paragraphs: [
      `${BUSINESS_CONFIG.businessName} builds WhatsApp AI automation, FAQ handling, and enquiry collection workflows for businesses. When a user messages a configured WhatsApp Business number, incoming message content and sender metadata are processed to generate automated replies, answer business questions, collect lead details, or route requests to human staff.`,
      'Where AI-assisted or automated workflows are active, messages may be processed by connected workflow orchestration tools (such as n8n) and AI language models strictly to fulfill the customer conversation or enquiry flow. Users may request human assistance or ask to stop receiving further messages at any time.',
    ],
  },
  {
    number: '05',
    id: 'third-party-services',
    title: 'Third-Party Services, Including Meta WhatsApp Cloud API',
    paragraphs: [
      'Our website links to external communication platforms, and our client automation solutions rely on third-party infrastructure providers depending on the services selected:',
    ],
    bullets: [
      'Meta Platforms & Meta WhatsApp Cloud API: Direct WhatsApp chats initiated from this website and automated WhatsApp Business messaging workflows use Meta Platforms / WhatsApp services and the official Meta WhatsApp Cloud API, subject to Meta’s applicable Privacy Policy and WhatsApp Business Terms.',
      `Email Service Providers: Consultation and enquiry emails sent to ${BUSINESS_CONFIG.email} are transmitted and processed by your email provider and our email provider.`,
      'Automation & Integration Tools (For Client Deployments): Depending on the agreed service scope, client workflows may integrate with Telegram Bot API, Google Sheets, CRM software, n8n workflow hosting, AI model providers, or telephony/voice providers.',
    ],
  },
  {
    number: '06',
    id: 'data-storage-and-security',
    title: 'Data Storage and Security',
    paragraphs: [
      `This website does not operate user accounts or store submitted contact or appointment form entries in an on-site website database. Enquiries sent by you are stored within our business email inbox (${BUSINESS_CONFIG.email}) or WhatsApp Business messaging history.`,
      'We apply reasonable administrative and technical steps—such as HTTPS website delivery and account access controls on our email and messaging tools—to help protect correspondence against unauthorized access. However, no method of electronic transmission or storage can be guaranteed completely secure.',
    ],
  },
  {
    number: '07',
    id: 'data-retention-and-deletion',
    title: 'Data Retention and Deletion',
    paragraphs: [
      'We keep enquiry correspondence and consultation details only for as long as reasonably necessary to respond to your request, schedule or conduct consultations, provide requested automation services, or meet applicable legal obligations.',
      `To request deletion of your enquiry emails or WhatsApp correspondence, please email ${BUSINESS_CONFIG.email} with your name and the email address or phone number used in your enquiry so we can locate and remove your correspondence records.`,
    ],
  },
  {
    number: '08',
    id: 'user-rights',
    title: 'User Rights',
    paragraphs: [
      'Subject to applicable laws, you may contact us to exercise the following choices regarding the personal information you have shared with us:',
    ],
    bullets: [
      'Access & Information: Request confirmation of what enquiry or contact details we hold from your correspondence.',
      'Correction: Ask us to update or correct inaccurate contact or business details you submitted.',
      'Deletion: Request deletion of your enquiry records or conversation history.',
      'Opt-Out / Withdrawal of Consent: Ask us to stop contacting you regarding a consultation or service enquiry.',
    ],
  },
  {
    number: '09',
    id: 'contact-information',
    title: 'Contact Information',
    paragraphs: [
      `If you have questions about this Privacy Policy, how your enquiry data is handled, or wish to submit a data access or deletion request, please contact ${BUSINESS_CONFIG.businessName}:`,
    ],
    bullets: [
      `Business Name: ${BUSINESS_CONFIG.businessName}`,
      `Email: ${BUSINESS_CONFIG.email}`,
      `Location: ${BUSINESS_CONFIG.location}`,
    ],
  },
  {
    number: '10',
    id: 'policy-updates',
    title: 'Updates to This Privacy Policy',
    paragraphs: [
      'We may update this Privacy Policy from time to time to reflect changes in our services, technical integrations, or applicable requirements. Any updated version will be published on this page at /privacy-policy with an updated effective date.',
    ],
  },
];

export function PrivacyPolicyPage({ onNavigate }: PrivacyPolicyPageProps) {
  const deletionEmailHref = buildMailtoUrl(
    `Privacy / Data Request — ${BUSINESS_CONFIG.businessName}`,
    `Hello ${BUSINESS_CONFIG.businessName},\n\nI would like to make a privacy / data request regarding my enquiry information.`
  );

  return (
    <div className="mx-auto max-w-4xl px-4 py-14 sm:px-6 lg:px-8 lg:py-20 space-y-10">
      <div className="space-y-4">
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="inline-flex items-center gap-2 text-sm font-medium text-[#22D3EE] hover:text-[#F8FAFC] transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>Back to Home</span>
        </button>

        <header className="space-y-3">
          <p className="text-xs font-medium tracking-[0.16em] text-[#22D3EE]">
            Legal &amp; Data Practices
          </p>
          <h1 className="font-display text-3xl font-bold tracking-tight text-[#F8FAFC] text-balance sm:text-5xl">
            Privacy Policy
          </h1>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#CBD5E1]/90">
            <span>{BUSINESS_CONFIG.businessName}</span>
            <span aria-hidden="true">·</span>
            <span>Location: {BUSINESS_CONFIG.location}</span>
            <span aria-hidden="true">·</span>
            <span>Effective Date: {EFFECTIVE_DATE}</span>
          </div>
        </header>
      </div>

      {/* Policy Sections */}
      <div className="space-y-6">
        {POLICY_SECTIONS.map((section) => (
          <section
            key={section.id}
            id={section.id}
            className="aurora-glass rounded-2xl border border-white/10 p-6 sm:p-8 space-y-4"
          >
            <div className="flex items-baseline gap-3">
              <span className="font-mono text-xs font-medium tabular-nums text-[#22D3EE]">
                {section.number}.
              </span>
              <h2 className="font-display text-xl font-bold text-[#F8FAFC] sm:text-2xl">
                {section.title}
              </h2>
            </div>

            <div className="space-y-3 text-sm sm:text-base leading-relaxed text-[#CBD5E1]">
              {section.paragraphs.map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}
            </div>

            {section.bullets && (
              <ul className="space-y-2.5 pt-1">
                {section.bullets.map((bullet, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-2.5 text-sm leading-relaxed text-[#CBD5E1]"
                  >
                    <span className="text-[#8B5CF6] font-bold mt-0.5" aria-hidden="true">
                      ·
                    </span>
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        ))}
      </div>

      {/* Direct Privacy Contact Action */}
      <section className="rounded-2xl border border-white/10 bg-[#172036]/55 p-6 sm:p-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="space-y-1">
          <h2 className="font-display text-lg font-bold text-[#F8FAFC]">
            Questions or Data Deletion Requests?
          </h2>
          <p className="text-sm text-[#CBD5E1]">
            Email us directly at{' '}
            <a
              href={`mailto:${BUSINESS_CONFIG.email}`}
              className="text-[#22D3EE] hover:underline break-all"
            >
              {BUSINESS_CONFIG.email}
            </a>
            .
          </p>
        </div>

        <a
          href={deletionEmailHref}
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#6D28D9] px-5 py-3 text-sm font-semibold text-[#F8FAFC] hover:from-[#9D74F7] hover:to-[#7C3AED] transition-all duration-150 whitespace-nowrap shrink-0"
        >
          <Mail className="w-4 h-4" aria-hidden="true" />
          <span>Contact Privacy Email</span>
        </a>
      </section>
    </div>
  );
}
